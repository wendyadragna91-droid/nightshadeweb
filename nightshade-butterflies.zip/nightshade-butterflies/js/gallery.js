async function uploadImage(){
let file=galleryFile.files[0];
let res=await storage.createFile(BUCKET_ID,'unique()',file);
galleryGrid.innerHTML+=`
<img src="https://cloud.appwrite.io/v1/storage/buckets/${BUCKET_ID}/files/${res.$id}/view?project=YOUR_PROJECT_ID">`;
}