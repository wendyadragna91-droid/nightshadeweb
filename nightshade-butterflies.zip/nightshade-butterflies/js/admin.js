async function assignRole(){
if(currentUserRole!=="Admin"){
alert("Admin only");
return;
}

let users=await databases.listDocuments(DB_ID,USERS_ID);
userSelect.innerHTML="";
users.documents.forEach(u=>{
userSelect.innerHTML+=`<option value="${u.$id}">${u.displayName}</option>`;
});

await databases.updateDocument(DB_ID,USERS_ID,userSelect.value,{
role:roleSelect.value,
mistressName:mistressField.value
});
}

async function setShoutcast(){
await databases.createDocument(DB_ID,SETTINGS_ID,'unique()',{
shoutcastURL:shoutcastInput.value
});
audioPlayer.src=shoutcastInput.value;
}