async function createStory(){
await databases.createDocument(DB_ID,STORIES_ID,'unique()',{
authorId:currentUser.$id,
authorName:currentUser.email,
content:storyContent.value,
likes:0,
createdAt:new Date()
});
loadStories();
}

async function loadStories(){
let res=await databases.listDocuments(DB_ID,STORIES_ID);
storiesList.innerHTML="";
res.documents.forEach(doc=>{
storiesList.innerHTML+=`
<div class="card">
<strong>${doc.authorName}</strong>
<p>${doc.content}</p>
❤️ ${doc.likes}
</div>`;
});
}
loadStories();