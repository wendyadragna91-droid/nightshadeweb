async function register(){
await account.create('unique()', email.value, password.value);
await login();
}

async function login(){
await account.createEmailSession(email.value,password.value);
currentUser = await account.get();
alert("Logged in");
loadUserRole();
}