client.subscribe(`databases.${DB_ID}.collections.${CHAT_ID}.documents`, response=>{
let msg=response.payload;
chatMessages.innerHTML+=`<p>${msg.sender}: ${msg.message}</p>`;
});

async function sendMessage(){
await databases.createDocument(DB_ID,CHAT_ID,'unique()',{
sender:currentUser.email,
message:chatInput.value,
createdAt:new Date()
});
chatInput.value="";
}