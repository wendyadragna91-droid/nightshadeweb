function enterSite(){
document.querySelector(".hero").style.display="none";
document.getElementById("mainContent").classList.remove("hidden");
}