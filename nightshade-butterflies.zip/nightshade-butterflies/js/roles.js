async function loadUserRole(){
let res = await databases.listDocuments(DB_ID, USERS_ID);
let userDoc = res.documents.find(d=>d.$id===currentUser.$id);

if(!userDoc){
await databases.createDocument(DB_ID, USERS_ID, currentUser.$id,{
displayName: displayName.value,
role:"Promoters",
mistressName:""
});
currentUserRole="Promoters";
}else{
currentUserRole=userDoc.role;
}

if(currentUserRole==="Admin" || currentUserRole==="Managers"){
document.getElementById("eventCreator").classList.remove("hidden");
}
}