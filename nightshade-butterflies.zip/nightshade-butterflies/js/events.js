async function createEvent(){
if(currentUserRole!=="Admin" && currentUserRole!=="Managers"){
alert("Permission denied");
return;
}

await databases.createDocument(DB_ID,EVENTS_ID,'unique()',{
title:eventTitle.value,
description:eventDesc.value,
date:new Date(),
createdBy:currentUser.$id
});
loadEvents();
}

async function loadEvents(){
let res=await databases.listDocuments(DB_ID,EVENTS_ID);
eventsList.innerHTML="";
res.documents.forEach(doc=>{
eventsList.innerHTML+=`
<div class="card">
<strong>${doc.title}</strong>
<p>${doc.description}</p>
</div>`;
});
}
loadEvents();