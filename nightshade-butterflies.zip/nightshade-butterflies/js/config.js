const { Client, Account, Databases, Storage } = Appwrite;

const client = new Client()
.setEndpoint('https://cloud.appwrite.io/v1')
.setProject('YOUR_PROJECT_ID');

const account = new Account(client);
const databases = new Databases(client);
const storage = new Storage(client);

const DB_ID = "nightshadeDB";
const USERS_ID = "users";
const STORIES_ID = "stories";
const EVENTS_ID = "events";
const CHAT_ID = "chat";
const SETTINGS_ID = "settings";
const BUCKET_ID = "gallery";

let currentUser = null;
let currentUserRole = null;